# Codex Canvas Bridge — From prompt to canvas

60 seconds · 1920×1080 · 30 fps · English · silent · dark editorial technology style.

| Time | Story / on-screen text | Visual |
|---|---|---|
| 00–08 | Your design. Your intent. One missing connection. | A prompt and a canvas sit apart; a broken connection resolves. |
| 08–16 | Codex Canvas Bridge / From prompt to canvas. | Custom bridge symbol, project name, repository hero artwork. |
| 16–28 | Connect locally. Stay in control. | Codex + companion skill → local receiver → Figma Desktop plugin → current page. Numbered setup steps. |
| 28–41 | Read. Create. Refine. | Clearly labeled illustrative canvas: selection inspection, frame/text creation, Auto Layout update. Actual operation names from src/canvas.ts. |
| 41–51 | Bring the design back to your project. | JSON, previews, SVG and images flow into a local folder. Structured commands and temporary connection code. |
| 51–60 | Make the next change on your canvas. | Repository address, source available / noncommercial use, independent-project attribution. |

## Accuracy and assets

Evidence: README.en.md Features, Quick start, Development, Privacy and limitations; src/canvas.ts; scripts/receiver.mjs; scripts/canvas-cli.mjs.
No genuine Figma session is connected in this environment. Animated canvas and commands are workflow illustrations, not recorded execution. The repository hero is actual project artwork, not a live application screenshot. No speed, productivity, commercial-use or official-partnership claims are made. The project is source available under PolyForm Noncommercial 1.0.0, not OSI open source. No delete operation or arbitrary JavaScript execution is depicted. No actual connection credentials appear.

The artwork asset is copied from this repository: docs/images/hero.png. The custom bridge mark is a film graphic, not an official project logo. No third-party music, stock assets or external fonts.
