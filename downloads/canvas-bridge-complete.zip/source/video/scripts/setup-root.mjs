// Keep the repository lockfile byte-for-byte intact while using the official registry.
import {mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../../',import.meta.url));
const temp=await mkdtemp(path.join(tmpdir(),'canvas-bridge-deps-'));
function npm(args,cwd){const p=spawnSync(process.platform==='win32'?'npm.cmd':'npm',args,{cwd,stdio:'inherit'});if(p.error)throw p.error;if(p.status!==0)throw Error(`npm ${args.join(' ')} failed: ${p.status}`);}
try{
 await writeFile(path.join(temp,'package.json'),await readFile(path.join(root,'package.json')));
 const lock=JSON.parse(await readFile(path.join(root,'package-lock.json'),'utf8'));
 for(const entry of Object.values(lock.packages??{})){
   if(entry.resolved?.startsWith('https://registry.npmmirror.com/'))entry.resolved=entry.resolved.replace('https://registry.npmmirror.com/','https://registry.npmjs.org/');
 }
 await writeFile(path.join(temp,'package-lock.json'),JSON.stringify(lock,null,2));
 // npm verifies the original locked integrity for every artifact.
 npm(['ci','--no-audit','--no-fund'],temp);
 // The content-addressed cache now contains the exact locked artifacts.
 npm(['ci','--offline','--no-audit','--no-fund'],root);
}finally{await rm(temp,{recursive:true,force:true});}
