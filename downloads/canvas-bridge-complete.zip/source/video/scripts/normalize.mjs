import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
process.chdir(fileURLToPath(new URL('../',import.meta.url)));
const p=spawnSync('ffmpeg',['-v','error','-y','-i','out/remotion-master.mp4','-map','0:v:0','-an','-vf','scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-preset','medium','-crf','18','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-threads','4','-movflags','+faststart','out/canvas-bridge.mp4'],{stdio:'inherit'});
if(p.error)throw p.error;if(p.status!==0)process.exit(p.status??1);
console.log('Delivery MP4: H.264 / yuv420p / BT.709 / no audio.');
