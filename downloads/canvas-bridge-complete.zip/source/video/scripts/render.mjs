import {createRequire} from 'node:module';
import {readFile,mkdir,writeFile,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {sceneSvg,DURATION} from '../src/scene.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
process.chdir(root);
const out=path.join(root,'out');await mkdir(out,{recursive:true});
let playwright;
for(const spec of [process.env.PLAYWRIGHT_MODULE,'playwright','/opt/codex/cua_node/lib/node_modules/playwright/package.json'].filter(Boolean)){
 try{const req=createRequire(import.meta.url);playwright=spec.endsWith('package.json')?createRequire(spec)('playwright'):req(spec);break;}catch{}
}
if(!playwright)throw Error('Install Playwright or set PLAYWRIGHT_MODULE to its module path.');
const hero='data:image/png;base64,'+(await readFile('public/project-hero.png')).toString('base64');
const browser=await playwright.chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const stills=process.argv.includes('--stills');
const frames=stills?[130,350,710,940,1070,1200,1440,1720]:Array.from({length:DURATION},(_,i)=>i);
const dir=path.join(out,stills?'stills':'frames');await mkdir(dir,{recursive:true});
let cursor=0,done=0;
try{
 await Promise.all(Array.from({length:stills?1:4},async()=>{
 const page=await browser.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:1});
 await page.setContent('<html><body style="margin:0;background:#080d18"><div id="stage"></div></body></html>');
 while(cursor<frames.length){const f=frames[cursor++];
 await page.evaluate(svg=>{document.querySelector('#stage').innerHTML=svg},sceneSvg(f,hero));
 await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:path.join(dir,`${String(f).padStart(5,'0')}.jpg`),type:'jpeg',quality:92,animations:'disabled'});
 done++;if(done%150===0)console.log(`Frames ${done}/${frames.length}`);
 }
 await page.close();
 }));
}finally{await browser.close();}
if(!stills){
 const args=['-y','-framerate','30','-i',path.join(dir,'%05d.jpg'),'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart','-threads','4',path.join(out,'canvas-bridge.mp4')];
 await new Promise((resolve,reject)=>{const p=spawn('ffmpeg',args,{stdio:['ignore','ignore','pipe']});let log='';p.stderr.on('data',b=>{log=(log+b).slice(-6000)});p.on('error',reject);p.on('close',c=>c===0?resolve():reject(Error(log)));});
 await rm(dir,{recursive:true,force:true});
 console.log('Rendered out/canvas-bridge.mp4');
}else console.log('Rendered review stills.');
