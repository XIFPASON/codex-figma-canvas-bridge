import React, {useState, useEffect} from 'react';
import {Composition, registerRoot, useCurrentFrame, staticFile, Sequence, delayRender, continueRender, cancelRender} from 'remotion';
import {sceneSvg} from './scene.mjs';
const Scene = ({offset,hero}) => <div style={{width:1920,height:1080}} dangerouslySetInnerHTML={{__html:sceneSvg(useCurrentFrame()+offset,hero)}}/>;
const Film = () => {
  const [handle] = useState(() => delayRender('Load local project artwork'));
  const [hero,setHero] = useState('');
  useEffect(() => {
    fetch(staticFile('project-hero.png')).then(r=>{if(!r.ok)throw Error('Artwork missing');return r.blob()}).then(blob=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob)})).then(data=>{setHero(data);continueRender(handle)}).catch(cancelRender);
  },[handle]);
  return <>
    <Sequence from={0} durationInFrames={240} name="The missing connection"><Scene offset={0} hero={hero}/></Sequence>
    <Sequence from={240} durationInFrames={240} name="Meet the bridge"><Scene offset={240} hero={hero}/></Sequence>
    <Sequence from={480} durationInFrames={360} name="Connect locally"><Scene offset={480} hero={hero}/></Sequence>
    <Sequence from={840} durationInFrames={390} name="Read · Create · Refine"><Scene offset={840} hero={hero}/></Sequence>
    <Sequence from={1230} durationInFrames={300} name="Bring it home"><Scene offset={1230} hero={hero}/></Sequence>
    <Sequence from={1530} durationInFrames={270} name="Build your next idea"><Scene offset={1530} hero={hero}/></Sequence>
  </>;
};
registerRoot(() => <Composition id="CanvasBridge" component={Film} durationInFrames={1800} fps={30} width={1920} height={1080}/>);
