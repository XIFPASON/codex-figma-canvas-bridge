export const FPS=30, DURATION=1800;
const C={bg:'#080d18',panel:'#101b2c',line:'#293c55',white:'#edf4ff',muted:'#94a8bf',mint:'#77f3c4',blue:'#82aaff',orange:'#ffb983'};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const clamp=n=>Math.max(0,Math.min(1,n));
const ease=n=>1-Math.pow(1-clamp(n),3);
const text=(x,y,s,size=32,color=C.white,extra='')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" ${extra}>${esc(s)}</text>`;
const rect=(x,y,w,h,fill=C.panel,r=22,stroke=C.line)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="${stroke}"/>`;
const mono=(x,y,s,size=25,col=C.mint)=>text(x,y,s,size,col,'font-family="DejaVu Sans Mono,monospace"');
const tag=(x,y,s,col=C.mint)=>rect(x,y,s.length*13+36,38,'#142b2d',19,'none')+text(x+18,y+26,s,19,col,'letter-spacing="2"');
const arrow=(x1,y1,x2,y2,p=1)=>`<path d="M${x1} ${y1} L${x1+(x2-x1)*p} ${y1+(y2-y1)*p}" stroke="${C.mint}" stroke-width="3" fill="none" marker-end="url(#arrow)"/>`;
const group=(s,progress,dx=0,dy=25)=>`<g opacity="${clamp(progress)}" transform="translate(${dx*(1-ease(progress))} ${dy*(1-ease(progress))})">${s}</g>`;
const title=(k,h,sub)=>tag(110,134,k)+text(110,262,h,70,C.white,'font-weight="700" letter-spacing="-2"')+text(112,322,sub,28,C.muted);
const bridge=(x,y,scale=1)=>`<g transform="translate(${x} ${y}) scale(${scale})"><rect width="110" height="110" rx="29" fill="${C.mint}"/><path d="M22 69V45M88 69V45M22 56Q55 9 88 56M36 40V69M55 31V69M74 40V69" fill="none" stroke="${C.bg}" stroke-width="6" stroke-linecap="round"/></g>`;
function canvas(x,y,w,h,stage,p){
 let s=rect(x,y,w,h,'#111c2c',20)+rect(x,y,w,49,'#1b293d',20)+text(x+24,y+32,'CANVAS / CURRENT PAGE',17,C.muted,'letter-spacing="2"');
 s+=`<path d="M${x+120} ${y+49}V${y+h}" stroke="${C.line}"/>`;
 ['Layers','Frame','Title','Card','Button'].forEach((a,i)=>s+=text(x+16,y+85+i*43,a,16,i===1?C.mint:C.muted));
 let cx=x+155,cy=y+85;
 s+=rect(cx,cy,w-195,h-125,'#eef1f6',8,'none');
 if(stage>=1){s+=group(rect(cx+24,cy+24,w-243,h-173,'#fff',12,'#89a8ff')+text(cx+46,cy+67,'A better starting point.',25,'#192c44','font-weight="700"'),p);}
 if(stage>=2){const q=stage===2?p:1;s+=group(text(cx+46,cy+103,'Designed on your current page.',17,'#6b7c90')+rect(cx+40,cy+130,115,98,'#e1edff',12,'none')+rect(cx+169,cy+130,115,98,'#e5f6ed',12,'none')+rect(cx+40,cy+250,244,42,'#285de7',9,'none')+text(cx+105,cy+277,'Get started',17,'#fff'),q);}
 if(stage>=3)s+=group(`<rect x="${cx+24}" y="${cy+24}" width="${w-243}" height="${h-173}" fill="none" stroke="${C.blue}" stroke-width="3"/>`+tag(cx+30,cy-17,'AUTO LAYOUT',C.blue),p);
 return s;
}
export const scenes=[
 {start:0,end:240,name:'The missing connection',subtitle:'Turn intent into changes on your current Figma canvas.'},
 {start:240,end:480,name:'Meet the bridge',subtitle:'Codex Canvas Bridge connects Codex to a local Figma desktop plugin.'},
 {start:480,end:840,name:'Connect locally',subtitle:'Start the receiver. Import the plugin. Connect and allow canvas editing.'},
 {start:840,end:1230,name:'Read · Create · Refine',subtitle:'Inspect a selection, create nodes, and refine layout with structured commands.'},
 {start:1230,end:1530,name:'Bring it home',subtitle:'Export design data, previews, SVGs and images to a local folder.'},
 {start:1530,end:1800,name:'Build your next idea',subtitle:'Explore the source and follow the local setup guide on GitHub.'}
];
export function sceneSvg(frame,hero=''){
 const idx=scenes.findIndex(s=>frame>=s.start&&frame<s.end), sc=scenes[Math.max(0,idx)], f=frame-sc.start,t=f/30;
 let s='';
 if(idx===0){
 s+=group(title('01 / THE GAP','Your design. Your intent.','One missing connection.'),f/25);
 s+=group(rect(110,405,670,365)+tag(144,435,'CODEX')+mono(146,541,'> Refine this layout.',32)+mono(146,597,'  Keep the design editable.',27,C.muted)+text(146,703,'An idea is only the beginning.',23,C.muted), (f-25)/25);
 s+=group(canvas(1090,405,720,430,2,1),(f-40)/25);
 const p=ease((f-110)/75);s+=`<path d="M800 588H1070" stroke="${C.line}" stroke-width="3" stroke-dasharray="8 12"/>`+arrow(800,588,1070,588,p);
 s+=group(bridge(896,533,0.7),(f-145)/25);
 }
 if(idx===1){
 s+=group(bridge(110,164,1.15),f/24)+group(tag(275,178,'LOCAL-FIRST DESIGN WORKFLOW')+text(275,263,'Codex Canvas Bridge',76,C.white,'font-weight="700" letter-spacing="-3"'),(f-8)/25);
 s+=group(text(110,398,'From prompt',86,C.white,'font-weight="700"')+text(110,500,'to canvas.',86,C.mint,'font-weight="700"'),(f-26)/30);
 s+=group(text(114,586,'Read and edit the current Figma page.',28,C.muted)+text(114,635,'Through a local desktop plugin.',28,C.muted)+tag(114,710,'NO OFFICIAL FIGMA MCP SETUP'),(f-50)/30);
 if(hero)s+=group(rect(990,388,820,462)+`<image href="${esc(hero)}" x="1002" y="400" width="796" height="438" preserveAspectRatio="xMidYMid meet"/>`+text(1000,888,'PROJECT ARTWORK / FROM THE REPOSITORY',18,C.muted,'letter-spacing="2"'),(f-40)/30);
 }
 if(idx===2){
 s+=group(title('02 / CONNECT','A local connection. A clear workflow.','Keep the plugin open while controlling the canvas.'),f/25);
 const labels=[['Codex','+ companion skill'],['Local receiver','127.0.0.1'],['Figma Desktop','development plugin'],['Current page','read + edit']];
 labels.forEach(([a,b],i)=>{let x=110+i*440;s+=group(rect(x,417,380,175)+tag(x+25,441,`0${i+1}`)+text(x+25,515,a,32,C.white,'font-weight="700"')+text(x+25,558,b,22,C.muted),(f-25-i*13)/25);if(i<3)s+=arrow(x+389,505,x+429,505,ease((f-60-i*20)/30));});
 const steps=['Start the local receiver','Import manifest.json in Figma','Enter the connection code','Connect and allow canvas editing'];
 steps.forEach((a,i)=>s+=group(text(135,680+i*48,`0${i+1}`,22,C.mint)+text(195,680+i*48,a,26,C.white),(f-115-i*28)/20));
 s+=group(tag(1070,693,'TEMPORARY CONNECTION CODE')+text(1070,779,'You choose when to connect.',29,C.muted),(f-210)/30);
 }
 if(idx===3){
 let phase=Math.min(2,Math.floor(f/130)),lf=f-phase*130;
 s+=group(title('03 / ON THE CANVAS',['Read the selection.','Create what comes next.','Refine the details.'][phase],['Understand nodes and their properties.','Frames, text, components and shapes.','Typography, colors, dimensions and Auto Layout.'][phase]),Math.min(f/25,1));
 s+=rect(110,398,740,464)+tag(140,426,'STRUCTURED COMMAND / ILLUSTRATION');
 const lines=phase===0?['{','  "op": "get_selection",','  "args": {}','}']:phase===1?['{','  "op": "create",','  "args": { ... }','}']:['{','  "op": "update",','  "args": { ... }','}'];
 lines.forEach((a,i)=>s+=group(mono(150,535+i*49,a,29,i===1?C.mint:C.muted),(lf-10-i*8)/14));
 s+=group(tag(145,784,phase===0?'INSPECT FIRST':phase===1?'EDITABLE FIGMA NODES':'LAYOUT + STYLE'),(lf-60)/20);
 s+=canvas(947,398,863,464,phase+1,ease((lf-25)/60));
 s+=text(110,909,'WORKFLOW ILLUSTRATION · NOT A LIVE FIGMA RECORDING · ARGUMENTS ABBREVIATED',18,C.muted,'letter-spacing="1"');
 }
 if(idx===4){
 s+=group(title('04 / BACK TO YOUR PROJECT','Keep the design within reach.','Design data and assets, saved to a local folder.'),f/25);
 const files=[['design.json','STRUCTURE'],['preview.png','PREVIEW'],['assets/*.svg','VECTORS'],['assets/*','IMAGES']];
 files.forEach(([a,b],i)=>{let x=110+i*306,y=427+Math.sin(t*1.3+i)*8;s+=group(rect(x,y,267,203)+`<path d="M${x+30} ${y+32}h36l14 14v41h-50z" fill="none" stroke="${C.mint}" stroke-width="2"/>`+mono(x+25,y+130,a,23,C.white)+text(x+25,y+172,b,17,C.muted,'letter-spacing="2"'),(f-25-i*14)/25);});
 s+=group(rect(1390,420,420,220,'#102c2a',22,'#346358')+text(1430,494,'LOCAL PROJECT',22,C.mint,'letter-spacing="3"')+mono(1430,558,'design/figma/',33,C.white)+text(1430,602,'JSON · previews · assets',23,C.muted),(f-80)/30);
 s+=arrow(1305,530,1372,530,ease((f-100)/30));
 s+=group(tag(110,750,'STRUCTURED OPERATIONS')+tag(560,750,'LOOPBACK RECEIVER')+tag(970,750,'NO CLOUD UPLOAD BY DEFAULT'),(f-145)/30);
 s+=group(text(112,850,'Canvas control and design export are separate modes.',27,C.muted),(f-190)/30);
 }
 if(idx===5){
 s+=group(bridge(110,172,1),f/25)+group(tag(260,186,'CODEX CANVAS BRIDGE'),(f-10)/25);
 s+=group(text(110,416,'Make the next change',88,C.white,'font-weight="700" letter-spacing="-3"')+text(110,523,'on your canvas.',88,C.mint,'font-weight="700" letter-spacing="-3"'),(f-20)/30);
 s+=group(rect(110,610,1700,102,'#15243a',18,'#38546e')+mono(147,676,'github.com/XIFPASON/codex-figma-canvas-bridge',37,C.white),(f-45)/30);
 s+=group(text(112,783,'Read the guide. Connect locally. Start with your selection.',31,C.muted)+tag(112,840,'SOURCE AVAILABLE / NONCOMMERCIAL USE'),(f-85)/30);
 s+=group(text(112,931,'Independent project. Not affiliated with Figma or OpenAI.',21,C.muted),(f-110)/30);
 }
 const fade=Math.min(ease(f/16),ease((sc.end-frame)/14));
 let grid='';for(let x=0;x<1920;x+=80)grid+=`<path d="M${x} 0V1080"/>`;for(let y=0;y<1080;y+=80)grid+=`<path d="M0 ${y}H1920"/>`;
 return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1920" height="1080" viewBox="0 0 1920 1080"><defs><radialGradient id="glow"><stop stop-color="#173849" stop-opacity=".6"/><stop offset="1" stop-color="${C.bg}" stop-opacity="0"/></radialGradient><marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0 0L6 3L0 6" fill="none" stroke="${C.mint}" stroke-width="1.4"/></marker></defs><rect width="1920" height="1080" fill="${C.bg}"/><ellipse cx="${1400+Math.sin(frame/120)*100}" cy="250" rx="950" ry="700" fill="url(#glow)"/><g stroke="#67859c" stroke-opacity=".055">${grid}</g><g font-family="DejaVu Sans,Arial,sans-serif">${text(110,70,'CANVAS / BRIDGE',19,C.muted,'letter-spacing="5"')}${text(1620,70,`${String(idx+1).padStart(2,'0')} / 06`,20,C.muted,'letter-spacing="3"')}<g opacity="${fade}">${s}</g><rect x="0" y="978" width="1920" height="102" fill="#080d18"/>${text(960,1032,sc.subtitle,25,C.white,'text-anchor="middle"')}<rect x="110" y="1061" width="1700" height="3" fill="${C.line}"/><rect x="110" y="1061" width="${1700*frame/1799}" height="3" fill="${C.mint}"/></g></svg>`;
}
