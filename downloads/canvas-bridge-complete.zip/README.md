# Codex Canvas Bridge — film project

60-second English, silent promotional film. 1920×1080, 30 fps, H.264 MP4, burned-in English captions. No music or narration. Project functionality is based on the parent repository; the canvas animation is explicitly labeled as an illustration. There is no real Figma session recording.

The source archive contains the independent `video/` project, installed official skills and license. Extract it at the parent repository root to retain the documented paths. It does not bundle node_modules or private Figma data.

## Files

- `out/canvas-bridge.mp4`: finished video (generated, ignored by Git).
- `storyboard.md`: timing, narrative and evidence.
- `src/index.jsx`: Remotion composition and six named timeline sequences.
- `src/scene.mjs`: shared deterministic SVG animation, text, colors and geometry.
- `public/project-hero.png`: repository artwork copied from `docs/images/hero.png`.
- `captions.srt`: optional external captions; the MP4 already has visible captions.
- `scripts/render.mjs`: alternate Chromium + FFmpeg renderer using the exact same scenes.
- `out/stills/`, `out/contact-sheet.jpg`: visual review outputs.

Edit copy and animation in `src/scene.mjs`, scene timing in both `src/index.jsx` and `scene.mjs`. The composition is fixed at 30 fps; change all frame timing if adapting to another frame rate. Source editing is supported; SVG internals are not individually draggable layers in Studio.

## Preview and export

```sh
cd /workspace/codex-figma-canvas-bridge/video
npm ci
npm run studio -- --port=3000
# Standard Remotion renderer (downloads its default browser if necessary):
npm run render
# Tested on this cloud machine, using the preinstalled browser:
npm run render -- --browser-executable=/usr/bin/chromium --crf=18 --overwrite
```

The Remotion master is kept as `out/remotion-master.mp4`. The render wrapper then normalizes its full-range color and removes the automatically added silent audio track using FFmpeg, producing `out/canvas-bridge.mp4`. Run `npm run verify` to validate and extract final review frames.

Use Node.js 22+; this environment was validated with Node.js 24.22.1. All Remotion packages are pinned to 4.0.320 in package-lock.json. Official skills are installed under `../.agents/skills/remotion-best-practices/`; `../skills-lock.json` records the source.

This cloud executor needs the supported elevated execution mode for Chromium's system calls and proxy networking. If a sandboxed command reports `setsockopt EPERM`, retry through the tool's permission mechanism. Do not disable TLS, checksum verification, or bypass the network proxy. Remotion's default browser downloader failed here with `EAI_AGAIN storage.googleapis.com`; the installed system Chromium was verified through an actual render instead.

## Alternate renderer

```sh
npm run stills
npm run render:offline
```

The alternate path needs Playwright, Chromium and FFmpeg. On this machine it uses the existing Playwright installation at `/opt/codex/cua_node/lib/node_modules/playwright`. Elsewhere install Playwright or supply `PLAYWRIGHT_MODULE`; use `CHROMIUM_PATH` for another Chromium path. It writes 1800 temporary JPEGs, encodes H.264 and removes them after successful encoding. It is deterministic and renders the same `sceneSvg` function as Remotion.

## Parent project setup

The original lockfile points to registry.npmmirror.com, which this network policy denies. Run `node video/scripts/setup-root.mjs` from the parent checkout: it stages a temporary lockfile using registry.npmjs.org, preserves all original integrity hashes, fills npm's content-addressed cache, and runs the original lockfile installation offline. It never edits the tracked lockfile. Then run `npm run typecheck`, `npm test`, and `npm run build` in the parent directory.

The receiver binds to loopback on the machine running Figma Desktop. A receiver on this cloud machine cannot directly control Figma running on your own computer. Follow the parent README for local end-to-end use. No Figma credentials are needed to edit or render this film.

## Licensing and attribution

Parent project: PolyForm Noncommercial License 1.0.0. Source available for noncommercial use; no OSI open-source or commercial-license claim. The film includes this limitation and independent-project attribution. No paid stock media, external fonts or third-party music are used. The bridge symbol is a custom illustration for the film, not an official logo. Repository artwork is labeled as such.
